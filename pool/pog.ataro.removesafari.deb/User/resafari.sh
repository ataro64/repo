Echo "this will reinstall safari that was removed by safariremover"
Mv /User/safari/MobileSafari.app /Applications
Uicache -a
echo "this will reinstall safari that was removed by safariremover"
mv /User/safari/MobileSafari.app /Applications
uicache -ar
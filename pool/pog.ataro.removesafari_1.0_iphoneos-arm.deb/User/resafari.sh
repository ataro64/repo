echo "this will reinstall safari that was removed by safariremover"
mv /User/safari/MobileSafari.app /Applications/
echo "running uicache"
uicache -p /Applications/MobileSafari.app -r
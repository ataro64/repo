echo "this will reinstall safari that was removed by safariremover"
mv /User/safari/MobileSafari.app /Applications/
apt remove pog.ataro.removesafari
echo "running uicache"
uicache -p /Applications/MobileSafari.app -r